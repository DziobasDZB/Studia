#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "mythread.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:

    void tick();

    void on_sterowanie_polacz_clicked();

    void on_sterowanie_rozlacz_clicked();

    void on_sterowanie_swiatlo1_2_clicked();

    void on_sterowanie_swiatlo2_2_clicked();

    void on_sterowanie_swiatlo3_2_clicked();

    void on_sterowanie_okno1_2_clicked();

    void on_sterowanie_okno2_2_clicked();

    void on_sterowanie_okno3_2_clicked();

    void on_sterowanie_klima_wl_2_clicked();

    void on_sterowanie_klima_wyl_2_clicked();

    void on_sterowanie_dzwi_otwarte_2_clicked();

    void on_sterowanie_dzwi_zamkniete_2_clicked();

    void on_sterowanie_robot1_2_clicked();

    void on_sterowanie_robot2_2_clicked();

    void on_sterowanie_robot3_2_clicked();

    void on_sterowanie_robot4_2_clicked();

    void on_sterowanie_robot5_2_clicked();

    void on_sterowanie_robot6_2_clicked();

    void on_sterowanie_alarm_wl_2_clicked();

    void on_sterowanie_alarm_wyl_2_clicked();

    void on_sterowanie_dym_wl_2_clicked();

    void on_sterowanie_dym_wyl_2_clicked();

    void on_pushButton_clicked();

    void on_sterowanie_zaluzie1_2_valueChanged(int value);

    void on_sterowanie_zaluzje2_2_valueChanged(int value);

    void on_sterowanie_zaluzje3_2_valueChanged(int value);

    void on_sterowanie_temperatura_2_valueChanged(int value);

    void on_info_nazwa_pomieszczenia_1_editingFinished();

    void on_info_nazwa_pomieszczenia_2_editingFinished();

    void on_sterowanie_swiatlo1_clicked();

    void on_sterowanie_swiatlo2_clicked();

    void on_sterowanie_swiatlo3_clicked();

    void on_sterowanie_okno1_clicked();

    void on_sterowanie_okno2_clicked();

    void on_sterowanie_klima_wl_clicked();

    void on_sterowanie_klima_wyl_clicked();

    void on_sterowanie_dzwi_otwarte_clicked();

    void on_sterowanie_dzwi_zamkniete_clicked();

    void on_sterowanie_zaluzie1_valueChanged(int value);

    void on_sterowanie_zaluzje2_valueChanged(int value);

    void on_sterowanie_temperatura_valueChanged(int value);

    void on_sterowanie_robot1_clicked();

    void on_sterowanie_robot2_clicked();

    void on_sterowanie_robot3_clicked();

    void on_sterowanie_robot4_clicked();

    void on_sterowanie_alarm_wl_clicked();

    void on_sterowanie_alarm_wyl_clicked();

    void on_sterowanie_dym_wl_clicked();

    void on_sterowanie_dym_wyl_clicked();

    void on_sterowanie_wyslij_clicked();

public:
    Ui::MainWindow *ui;
    Thread *watek1;
};

#endif // MAINWINDOW_H
