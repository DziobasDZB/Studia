#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "var.h"
#include <QSerialPortInfo>
#include <QSerialPort>
#include <QDebug>
#include <QSettings>
#include <QtCore>
#include <QThread>
#include <QStringList>

QSerialPort *serial = NULL;
QString string_toSend = NULL;
QStringList data_toSend = (QStringList() << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "17" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0" << "0");

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    watek1 = new Thread();
    connect(watek1, SIGNAL(sygnal()), this, SLOT(tick()));
    watek1->start();
    QWidget::setWindowTitle("Inteligentny System Zarządzania Domem");

}

MainWindow::~MainWindow()
{
    serial->close();
    watek1->terminate();
    delete ui;
}

void MainWindow::tick()
{
    if (p == 1)
    {
        reci_s = "";
        reci_s = serial->readAll();
        qDebug() << reci_s << endl;
        QStringList dane = reci_s.split("|");

        if (dane[0] == numer_pokoju_1)
        {
            if (dane.size() > 1){

                if (dane[1] == "1")
                    ui->sterowanie_swiatlo1_2->setChecked(true);
                else if(dane[1] == "0")
                    ui->sterowanie_swiatlo1_2->setChecked(false);

                if (dane[2] == "1")
                    ui->sterowanie_swiatlo2_2->setChecked(true);
                else if(dane[2] == "0")
                    ui->sterowanie_swiatlo2_2->setChecked(false);

                if (dane[3] == "1")
                    ui->sterowanie_swiatlo3_2->setChecked(true);
                else if(dane[3] == "0")
                    ui->sterowanie_swiatlo3_2->setChecked(false);

                if (dane[4] == "1")
                    ui->sterowanie_okno1_2->setChecked(true);
                else if(dane[2] == "0")
                    ui->sterowanie_okno2_2->setChecked(false);

                if (dane[5] == "1")
                    ui->sterowanie_okno2_2->setChecked(true);
                else if(dane[5] == "0")
                    ui->sterowanie_okno2_2->setChecked(false);

                if (dane[6] == "1")
                    ui->sterowanie_okno3_2->setChecked(true);
                else if(dane[6] == "0")
                    ui->sterowanie_okno3_2->setChecked(false);

                if (dane[7] == "1")
                    ui->sterowanie_klima_wl_2->setChecked(true);
                else if(dane[7] == "0")
                    ui->sterowanie_klima_wyl_2->setChecked(true);

                if (dane[8] == "1")
                    ui->sterowanie_dzwi_otwarte_2->setChecked(true);
                else if(dane[8] == "0")
                    ui->sterowanie_dzwi_zamkniete_2->setChecked(true);

                if (dane[9] == "1")
                    ui->sterowanie_robot1_2->setChecked(true);
                else if(dane[9] == "0")
                    ui->sterowanie_robot1_2->setChecked(false);

                if (dane[10] == "1")
                    ui->sterowanie_robot2_2->setChecked(true);
                else if(dane[10] == "0")
                    ui->sterowanie_robot2_2->setChecked(false);

                if (dane[11] == "1")
                    ui->sterowanie_robot3_2->setChecked(true);
                else if(dane[11] == "0")
                    ui->sterowanie_robot3_2->setChecked(false);

                if (dane[12] == "1")
                    ui->sterowanie_robot4_2->setChecked(true);
                else if(dane[12] == "0")
                    ui->sterowanie_robot4_2->setChecked(false);

                if (dane[13] == "1")
                    ui->sterowanie_robot5_2->setChecked(true);
                else if(dane[13] == "0")
                    ui->sterowanie_robot5_2->setChecked(false);

                if (dane[14] == "1")
                    ui->sterowanie_robot6_2->setChecked(true);
                else if(dane[14] == "0")
                    ui->sterowanie_robot6_2->setChecked(false);

                if (dane[15] == "1")
                    ui->sterowanie_alarm_wl_2->setChecked(true);
                else if(dane[15] == "0")
                    ui->sterowanie_alarm_wyl_2->setChecked(true);

                if (dane[16] == "1")
                    ui->sterowanie_dym_wl_2->setChecked(true);
                else if(dane[16] == "0")
                    ui->sterowanie_dym_wyl_2->setChecked(true);

                ui->sterowanie_zaluzie1_2->setSliderPosition(dane[17].toInt());
                ui->sterowanie_zaluzje2_2->setSliderPosition(dane[18].toInt());
                ui->sterowanie_zaluzje3_2->setSliderPosition(dane[19].toInt());

                ui->sterowanie_temperatura_2->setValue(dane[20].toInt());
                ui->info_temperatura_2->display(dane[20].toInt());


                for (int o = 1; o<30 ; o++)
                    data_toSend[o] = dane[o];

            }
        }
        else if (numer_pokoju_2 == dane[0])
        {

            if (dane[1] == "1")
                ui->sterowanie_swiatlo1->setChecked(true);
            else if(dane[1] == "0")
                ui->sterowanie_swiatlo1->setChecked(false);

            if (dane[2] == "1")
                ui->sterowanie_swiatlo2->setChecked(true);
            else if(dane[2] == "0")
                ui->sterowanie_swiatlo2->setChecked(false);

            if (dane[3] == "1")
                ui->sterowanie_swiatlo3->setChecked(true);
            else if(dane[3] == "0")
                ui->sterowanie_swiatlo3->setChecked(false);

            if (dane[4] == "1")
                ui->sterowanie_okno1->setChecked(true);
            else if(dane[4] == "0")
                ui->sterowanie_okno1->setChecked(false);

            if (dane[5] == "1")
                ui->sterowanie_okno2->setChecked(true);
            else if(dane[5] == "0")
                ui->sterowanie_okno2->setChecked(false);

            if (dane[6] == "1")
                ui->sterowanie_klima_wl->setChecked(true);
            else if(dane[6] == "0")
                ui->sterowanie_klima_wyl->setChecked(false);

            if (dane[7] == "1")
                ui->sterowanie_dzwi_otwarte->setChecked(true);
            else if(dane[7] == "0")
                ui->sterowanie_dzwi_zamkniete->setChecked(true);

            if (dane[11] == "1")
                ui->sterowanie_robot1->setChecked(true);
            else if(dane[11] == "0")
                ui->sterowanie_robot1->setChecked(false);

            if (dane[12] == "1")
                ui->sterowanie_robot2->setChecked(true);
            else if(dane[12] == "0")
                ui->sterowanie_robot2->setChecked(false);

            if (dane[13] == "1")
                ui->sterowanie_robot3->setChecked(true);
            else if(dane[13] == "0")
                ui->sterowanie_robot3->setChecked(false);

            if (dane[14] == "1")
                ui->sterowanie_robot4->setChecked(true);
            else if(dane[14] == "0")
                ui->sterowanie_robot4->setChecked(false);

            if (dane[15] == "1")
                ui->sterowanie_alarm_wl->setChecked(true);
            else if(dane[15] == "0")
                ui->sterowanie_alarm_wyl->setChecked(true);

            if (dane[16] == "1")
                ui->sterowanie_dym_wl->setChecked(true);
            else if(dane[16] == "0")
                ui->sterowanie_dym_wyl->setChecked(true);

            ui->sterowanie_zaluzie1->setSliderPosition(dane[8].toInt());
            ui->sterowanie_zaluzje2->setSliderPosition(dane[9].toInt());

            ui->sterowanie_temperatura->setValue(dane[10].toInt());
            ui->info_temperatura->display(dane[10].toInt());


            for (int o = 1; o<30 ; o++)
                data_toSend[o] = dane[o];


        }
    }
}

void MainWindow::on_sterowanie_polacz_clicked()
{
    serial = new QSerialPort(this);
    QString name = ui->info_nazwa_portu->text();
    serial->setPortName(name);
    serial->setBaudRate(9600);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    serial->setDataBits(QSerialPort::Data8);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setParity(QSerialPort::NoParity);
    serial->open(QIODevice::ReadWrite);

    if (serial->isOpen())
    {
        qDebug() << "OPEN port" << endl;
        ui->info_nazwa->setText("Połączono port: " + name + ".");
        p = 1;
    }
}

void MainWindow::on_sterowanie_rozlacz_clicked()
{
    if (serial->isOpen())
    {
        serial->close();
        if (serial->isOpen() == false)
        {
            qDebug() << "CLOSE port" << endl;
            ui->info_nazwa->setText("Rozłączono port.");
            p=0;
        }
    }
}

void MainWindow::on_sterowanie_swiatlo1_2_clicked()
{
    if (ui->sterowanie_swiatlo1_2->isChecked())
        data_toSend[1] = "1";
    else
        data_toSend[1] = "0";
}

void MainWindow::on_sterowanie_swiatlo2_2_clicked()
{
    if (ui->sterowanie_swiatlo2_2->isChecked())
        data_toSend[2] = "1";
    else
        data_toSend[2] = "0";
}

void MainWindow::on_sterowanie_swiatlo3_2_clicked()
{
    if (ui->sterowanie_swiatlo3_2->isChecked())
        data_toSend[3] = "1";
    else
        data_toSend[3] = "0";
}

void MainWindow::on_sterowanie_okno1_2_clicked()
{
    if (ui->sterowanie_okno1_2->isChecked())
        data_toSend[4] = "1";
    else
        data_toSend[4] = "0";
}

void MainWindow::on_sterowanie_okno2_2_clicked()
{
    if (ui->sterowanie_okno2_2->isChecked())
        data_toSend[5] = "1";
    else
        data_toSend[5] = "0";
}

void MainWindow::on_sterowanie_okno3_2_clicked()
{
    if (ui->sterowanie_okno3_2->isChecked())
        data_toSend[6] = "1";
    else
        data_toSend[6] = "0";
}

void MainWindow::on_sterowanie_klima_wl_2_clicked()
{
    data_toSend[7] = "1";
}

void MainWindow::on_sterowanie_klima_wyl_2_clicked()
{
    data_toSend[7] = "0";
}

void MainWindow::on_sterowanie_dzwi_otwarte_2_clicked()
{
    data_toSend[8] = "1";
}


void MainWindow::on_sterowanie_dzwi_zamkniete_2_clicked()
{
    data_toSend[8] = "0";
}

void MainWindow::on_sterowanie_robot1_2_clicked()
{
    if (ui->sterowanie_robot1_2->isChecked())
        data_toSend[9] = "1";
    else
        data_toSend[9] = "0";
}

void MainWindow::on_sterowanie_robot2_2_clicked()
{
    if (ui->sterowanie_robot2_2->isChecked())
        data_toSend[10] = "1";
    else
        data_toSend[10] = "0";
}

void MainWindow::on_sterowanie_robot3_2_clicked()
{
    if (ui->sterowanie_robot3_2->isChecked())
        data_toSend[11] = "1";
    else
        data_toSend[11] = "0";
}

void MainWindow::on_sterowanie_robot4_2_clicked()
{
    if (ui->sterowanie_robot4_2->isChecked())
        data_toSend[12] = "1";
    else
        data_toSend[12] = "0";
}

void MainWindow::on_sterowanie_robot5_2_clicked()
{
    if (ui->sterowanie_robot5_2->isChecked())
        data_toSend[13] = "1";
    else
        data_toSend[13] = "0";
}

void MainWindow::on_sterowanie_robot6_2_clicked()
{
    if (ui->sterowanie_robot6_2->isChecked())
        data_toSend[14] = "1";
    else
        data_toSend[14] = "0";
}

void MainWindow::on_sterowanie_alarm_wl_2_clicked()
{
    data_toSend[15] = "1";
}

void MainWindow::on_sterowanie_alarm_wyl_2_clicked()
{
    data_toSend[15] = "0";
}

void MainWindow::on_sterowanie_dym_wl_2_clicked()
{
    data_toSend[16] = "1";
}

void MainWindow::on_sterowanie_dym_wyl_2_clicked()
{
    data_toSend[16] = "0";
}


void MainWindow::on_pushButton_clicked()
{
    string_toSend = "";
    int x = 0;
    data_toSend[0] = numer_pokoju_1;
    while (x<30)
    {
        string_toSend.append(data_toSend[x]);
        string_toSend.append("|");
        x++;
    }
    // qDebug() << string_toSend << endl;
    if(p == 1)
    {
        datagram = NULL;
        datagram.append(string_toSend);
        serial->write(datagram);
    }
}

void MainWindow::on_sterowanie_zaluzie1_2_valueChanged(int value)
{
    data_toSend[17] = QString::number(value);
}

void MainWindow::on_sterowanie_zaluzje2_2_valueChanged(int value)
{
    data_toSend[18] = QString::number(value);
}

void MainWindow::on_sterowanie_zaluzje3_2_valueChanged(int value)
{
    data_toSend[19] = QString::number(value);
}

void MainWindow::on_sterowanie_temperatura_2_valueChanged(int value)
{
    data_toSend[20] = QString::number(value);
    ui->info_temperatura_2->display(value);
}

void MainWindow::on_info_nazwa_pomieszczenia_1_editingFinished()
{
    ui->tabWidget->setTabText(1, ui->info_nazwa_pomieszczenia_1->text());
}

void MainWindow::on_info_nazwa_pomieszczenia_2_editingFinished()
{
    ui->tabWidget->setTabText(2, ui->info_nazwa_pomieszczenia_2->text());
}

void MainWindow::on_sterowanie_swiatlo1_clicked()
{
    if (ui->sterowanie_swiatlo1->isChecked())
        data_toSend[1] = "1";
    else
        data_toSend[1] = "0";
}

void MainWindow::on_sterowanie_swiatlo2_clicked()
{
    if (ui->sterowanie_swiatlo2->isChecked())
        data_toSend[2] = "1";
    else
        data_toSend[2] = "0";
}

void MainWindow::on_sterowanie_swiatlo3_clicked()
{

    if (ui->sterowanie_swiatlo3->isChecked())
        data_toSend[3] = "1";
    else
        data_toSend[3] = "0";
}

void MainWindow::on_sterowanie_okno1_clicked()
{

    if (ui->sterowanie_okno1->isChecked())
        data_toSend[4] = "1";
    else
        data_toSend[4] = "0";
}

void MainWindow::on_sterowanie_okno2_clicked()
{
    if (ui->sterowanie_okno2->isChecked())
        data_toSend[5] = "1";
    else
        data_toSend[5] = "0";

}

void MainWindow::on_sterowanie_klima_wl_clicked()
{
    if (ui->sterowanie_klima_wl->isChecked())
        data_toSend[6] = "1";
    else
        data_toSend[6] = "0";

}

void MainWindow::on_sterowanie_klima_wyl_clicked()
{
    if (ui->sterowanie_klima_wyl->isChecked())
        data_toSend[6] = "1";
    else
        data_toSend[6] = "0";

}

void MainWindow::on_sterowanie_dzwi_otwarte_clicked()
{
    if (ui->sterowanie_dzwi_otwarte->isChecked())
        data_toSend[7] = "1";
    else
        data_toSend[7] = "0";

}

void MainWindow::on_sterowanie_dzwi_zamkniete_clicked()
{
    if (ui->sterowanie_dzwi_zamkniete->isChecked())
        data_toSend[7] = "1";
    else
        data_toSend[7] = "0";
}

void MainWindow::on_sterowanie_zaluzie1_valueChanged(int value)
{
    data_toSend[8] = QString::number(value);
}

void MainWindow::on_sterowanie_zaluzje2_valueChanged(int value)
{
    data_toSend[9] = QString::number(value);
}

void MainWindow::on_sterowanie_temperatura_valueChanged(int value)
{
    data_toSend[10] = QString::number(value);
    ui->info_temperatura->display(value);
}

void MainWindow::on_sterowanie_robot1_clicked()
{
    if (ui->sterowanie_robot1->isChecked())
        data_toSend[11] = "1";
    else
        data_toSend[11] = "0";
}

void MainWindow::on_sterowanie_robot2_clicked()
{
    if (ui->sterowanie_robot2->isChecked())
        data_toSend[12] = "1";
    else
        data_toSend[12] = "0";
}

void MainWindow::on_sterowanie_robot3_clicked()
{
    if (ui->sterowanie_robot3->isChecked())
        data_toSend[13] = "1";
    else
        data_toSend[13] = "0";
}

void MainWindow::on_sterowanie_robot4_clicked()
{
    if (ui->sterowanie_robot4->isChecked())
        data_toSend[14] = "1";
    else
        data_toSend[14] = "0";
}

void MainWindow::on_sterowanie_alarm_wl_clicked()
{
    if (ui->sterowanie_alarm_wl->isChecked())
        data_toSend[15] = "1";
    else
        data_toSend[15] = "0";
}

void MainWindow::on_sterowanie_alarm_wyl_clicked()
{
    if (ui->sterowanie_alarm_wyl->isChecked())
        data_toSend[15] = "1";
    else
        data_toSend[15] = "0";
}

void MainWindow::on_sterowanie_dym_wl_clicked()
{
    if (ui->sterowanie_dym_wl->isChecked())
        data_toSend[16] = "1";
    else
        data_toSend[16] = "0";
}

void MainWindow::on_sterowanie_dym_wyl_clicked()
{
    if (ui->sterowanie_dym_wyl->isChecked())
        data_toSend[16] = "1";
    else
        data_toSend[16] = "0";
}

void MainWindow::on_sterowanie_wyslij_clicked()
{
    string_toSend = "";
    data_toSend[0] = numer_pokoju_2;
    int x = 0;
    while (x<30)
    {
        string_toSend.append(data_toSend[x]);
        string_toSend.append("|");
        x++;
    }
    // qDebug() << string_toSend << endl;
    if(p == 1)
    {
        datagram = NULL;
        datagram.append(string_toSend);
        serial->write(datagram);
    }
}
