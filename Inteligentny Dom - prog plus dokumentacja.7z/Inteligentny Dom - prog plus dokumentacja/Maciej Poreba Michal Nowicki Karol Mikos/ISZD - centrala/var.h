#ifndef VAR
#define VAR

#include <QString>
#include <QSerialPort>

extern QString numer_pokoju_1;
extern QString numer_pokoju_2;
extern QByteArray reci;
extern QByteArray datagram;
extern QString reci_s;
extern int p;

#endif // VAR

