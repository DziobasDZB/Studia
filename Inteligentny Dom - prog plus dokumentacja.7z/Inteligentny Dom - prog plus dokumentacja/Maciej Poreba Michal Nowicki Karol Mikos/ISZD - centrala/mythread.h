#ifndef MYTHREAD
#define MYTHREAD
#include <QThread>

class Thread : public QThread
{
    Q_OBJECT

public:
    void run();

signals:
    void sygnal();

};

#endif // MYTHREAD

