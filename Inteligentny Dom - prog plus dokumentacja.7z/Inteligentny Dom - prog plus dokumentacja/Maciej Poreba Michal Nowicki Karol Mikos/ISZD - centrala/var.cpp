#include "var.h"
#include <Qstring.h>

QString numer_pokoju_1 = "1";
QString numer_pokoju_2 = "2";
QByteArray reci = NULL;
QByteArray datagram = NULL;
QString reci_s;
int p = 0;
