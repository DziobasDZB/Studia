/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDial>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QPushButton *sterowanie_polacz;
    QLineEdit *info_nazwa;
    QPushButton *sterowanie_rozlacz;
    QLineEdit *info_nazwa_portu;
    QLabel *opis_nazwa;
    QLineEdit *info_nazwa_pomieszczenia_1;
    QLineEdit *info_nazwa_pomieszczenia_2;
    QLabel *opis_nazwa_2;
    QLabel *opis_nazwa_3;
    QWidget *tab_2;
    QGroupBox *grupa_dym;
    QRadioButton *sterowanie_dym_wyl_2;
    QRadioButton *sterowanie_dym_wl_2;
    QGroupBox *grupa_sprzety;
    QCheckBox *sterowanie_robot3_2;
    QCheckBox *sterowanie_robot2_2;
    QCheckBox *sterowanie_robot1_2;
    QCheckBox *sterowanie_robot6_2;
    QCheckBox *sterowanie_robot4_2;
    QCheckBox *sterowanie_robot5_2;
    QGroupBox *grupa_klimatyzacja;
    QLCDNumber *info_temperatura_2;
    QDial *sterowanie_temperatura_2;
    QGroupBox *grupa_alarm;
    QRadioButton *sterowanie_alarm_wyl_2;
    QRadioButton *sterowanie_alarm_wl_2;
    QGroupBox *grupa_klimatyzacja_2;
    QRadioButton *sterowanie_klima_wyl_2;
    QRadioButton *sterowanie_klima_wl_2;
    QGroupBox *grupa_zaluzje;
    QSlider *sterowanie_zaluzie1_2;
    QSlider *sterowanie_zaluzje2_2;
    QSlider *sterowanie_zaluzje3_2;
    QLabel *opis1_2;
    QLabel *opis2_2;
    QLabel *opis3_2;
    QGroupBox *grupa_dzwi;
    QRadioButton *sterowanie_dzwi_zamkniete_2;
    QRadioButton *sterowanie_dzwi_otwarte_2;
    QGroupBox *grupa_swiatlo;
    QCheckBox *sterowanie_swiatlo1_2;
    QCheckBox *sterowanie_swiatlo2_2;
    QCheckBox *sterowanie_swiatlo3_2;
    QGroupBox *grupa_okna;
    QCheckBox *sterowanie_okno1_2;
    QCheckBox *sterowanie_okno2_2;
    QCheckBox *sterowanie_okno3_2;
    QPushButton *pushButton;
    QWidget *tab_3;
    QGroupBox *grupa_klimatyzacja_3;
    QLCDNumber *info_temperatura;
    QDial *sterowanie_temperatura;
    QPushButton *sterowanie_wyslij;
    QGroupBox *grupa_dym_2;
    QRadioButton *sterowanie_dym_wyl;
    QRadioButton *sterowanie_dym_wl;
    QGroupBox *grupa_sprzety_2;
    QCheckBox *sterowanie_robot3;
    QCheckBox *sterowanie_robot2;
    QCheckBox *sterowanie_robot1;
    QCheckBox *sterowanie_robot4;
    QGroupBox *grupa_klimatyzacja_4;
    QRadioButton *sterowanie_klima_wyl;
    QRadioButton *sterowanie_klima_wl;
    QGroupBox *grupa_dzwi_2;
    QRadioButton *sterowanie_dzwi_zamkniete;
    QRadioButton *sterowanie_dzwi_otwarte;
    QGroupBox *grupa_zaluzje_2;
    QSlider *sterowanie_zaluzie1;
    QSlider *sterowanie_zaluzje2;
    QLabel *opis1;
    QLabel *opis2;
    QGroupBox *grupa_alarm_2;
    QRadioButton *sterowanie_alarm_wyl;
    QRadioButton *sterowanie_alarm_wl;
    QGroupBox *grupa_okna_2;
    QCheckBox *sterowanie_okno1;
    QCheckBox *sterowanie_okno2;
    QGroupBox *grupa_swiatlo_2;
    QCheckBox *sterowanie_swiatlo1;
    QCheckBox *sterowanie_swiatlo2;
    QCheckBox *sterowanie_swiatlo3;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QMenuBar *menuBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(651, 408);
        MainWindow->setStyleSheet(QLatin1String("background-color: rgb(21, 20, 21);\n"
"font: 75 11pt \"Comic Sans MS\";\n"
"color: rgb(85, 170, 255);"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 651, 391));
        tabWidget->setStyleSheet(QStringLiteral("background-image: url(:/artleo.com-8070.jpg);"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        sterowanie_polacz = new QPushButton(tab);
        sterowanie_polacz->setObjectName(QStringLiteral("sterowanie_polacz"));
        sterowanie_polacz->setGeometry(QRect(339, 231, 111, 31));
        info_nazwa = new QLineEdit(tab);
        info_nazwa->setObjectName(QStringLiteral("info_nazwa"));
        info_nazwa->setGeometry(QRect(339, 271, 231, 31));
        sterowanie_rozlacz = new QPushButton(tab);
        sterowanie_rozlacz->setObjectName(QStringLiteral("sterowanie_rozlacz"));
        sterowanie_rozlacz->setGeometry(QRect(459, 231, 111, 31));
        info_nazwa_portu = new QLineEdit(tab);
        info_nazwa_portu->setObjectName(QStringLiteral("info_nazwa_portu"));
        info_nazwa_portu->setGeometry(QRect(50, 60, 141, 31));
        opis_nazwa = new QLabel(tab);
        opis_nazwa->setObjectName(QStringLiteral("opis_nazwa"));
        opis_nazwa->setGeometry(QRect(50, 40, 111, 16));
        opis_nazwa->setStyleSheet(QStringLiteral(""));
        info_nazwa_pomieszczenia_1 = new QLineEdit(tab);
        info_nazwa_pomieszczenia_1->setObjectName(QStringLiteral("info_nazwa_pomieszczenia_1"));
        info_nazwa_pomieszczenia_1->setGeometry(QRect(340, 60, 141, 31));
        info_nazwa_pomieszczenia_2 = new QLineEdit(tab);
        info_nazwa_pomieszczenia_2->setObjectName(QStringLiteral("info_nazwa_pomieszczenia_2"));
        info_nazwa_pomieszczenia_2->setGeometry(QRect(340, 120, 141, 31));
        opis_nazwa_2 = new QLabel(tab);
        opis_nazwa_2->setObjectName(QStringLiteral("opis_nazwa_2"));
        opis_nazwa_2->setGeometry(QRect(340, 100, 111, 16));
        opis_nazwa_3 = new QLabel(tab);
        opis_nazwa_3->setObjectName(QStringLiteral("opis_nazwa_3"));
        opis_nazwa_3->setGeometry(QRect(340, 40, 111, 16));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        grupa_dym = new QGroupBox(tab_2);
        grupa_dym->setObjectName(QStringLiteral("grupa_dym"));
        grupa_dym->setGeometry(QRect(400, 180, 111, 101));
        grupa_dym->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_dym->setFlat(true);
        sterowanie_dym_wyl_2 = new QRadioButton(grupa_dym);
        sterowanie_dym_wyl_2->setObjectName(QStringLiteral("sterowanie_dym_wyl_2"));
        sterowanie_dym_wyl_2->setGeometry(QRect(10, 43, 91, 41));
        sterowanie_dym_wyl_2->setChecked(true);
        sterowanie_dym_wl_2 = new QRadioButton(grupa_dym);
        sterowanie_dym_wl_2->setObjectName(QStringLiteral("sterowanie_dym_wl_2"));
        sterowanie_dym_wl_2->setGeometry(QRect(10, 22, 111, 31));
        grupa_sprzety = new QGroupBox(tab_2);
        grupa_sprzety->setObjectName(QStringLiteral("grupa_sprzety"));
        grupa_sprzety->setGeometry(QRect(510, 100, 91, 181));
        grupa_sprzety->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_sprzety->setFlat(true);
        sterowanie_robot3_2 = new QCheckBox(grupa_sprzety);
        sterowanie_robot3_2->setObjectName(QStringLiteral("sterowanie_robot3_2"));
        sterowanie_robot3_2->setGeometry(QRect(10, 71, 71, 17));
        sterowanie_robot2_2 = new QCheckBox(grupa_sprzety);
        sterowanie_robot2_2->setObjectName(QStringLiteral("sterowanie_robot2_2"));
        sterowanie_robot2_2->setGeometry(QRect(10, 46, 71, 17));
        sterowanie_robot1_2 = new QCheckBox(grupa_sprzety);
        sterowanie_robot1_2->setObjectName(QStringLiteral("sterowanie_robot1_2"));
        sterowanie_robot1_2->setGeometry(QRect(10, 23, 71, 16));
        sterowanie_robot6_2 = new QCheckBox(grupa_sprzety);
        sterowanie_robot6_2->setObjectName(QStringLiteral("sterowanie_robot6_2"));
        sterowanie_robot6_2->setGeometry(QRect(10, 150, 71, 17));
        sterowanie_robot4_2 = new QCheckBox(grupa_sprzety);
        sterowanie_robot4_2->setObjectName(QStringLiteral("sterowanie_robot4_2"));
        sterowanie_robot4_2->setGeometry(QRect(10, 98, 71, 16));
        sterowanie_robot5_2 = new QCheckBox(grupa_sprzety);
        sterowanie_robot5_2->setObjectName(QStringLiteral("sterowanie_robot5_2"));
        sterowanie_robot5_2->setGeometry(QRect(10, 124, 71, 17));
        grupa_klimatyzacja = new QGroupBox(tab_2);
        grupa_klimatyzacja->setObjectName(QStringLiteral("grupa_klimatyzacja"));
        grupa_klimatyzacja->setGeometry(QRect(260, 99, 121, 181));
        grupa_klimatyzacja->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_klimatyzacja->setFlat(true);
        info_temperatura_2 = new QLCDNumber(grupa_klimatyzacja);
        info_temperatura_2->setObjectName(QStringLiteral("info_temperatura_2"));
        info_temperatura_2->setGeometry(QRect(20, 32, 81, 41));
        info_temperatura_2->setStyleSheet(QLatin1String("color: rgb(0, 0, 0);\n"
"border-color: rgb(0, 0, 0);"));
        info_temperatura_2->setProperty("intValue", QVariant(17));
        sterowanie_temperatura_2 = new QDial(grupa_klimatyzacja);
        sterowanie_temperatura_2->setObjectName(QStringLiteral("sterowanie_temperatura_2"));
        sterowanie_temperatura_2->setGeometry(QRect(20, 70, 81, 91));
        sterowanie_temperatura_2->setMinimum(17);
        sterowanie_temperatura_2->setMaximum(27);
        grupa_alarm = new QGroupBox(tab_2);
        grupa_alarm->setObjectName(QStringLiteral("grupa_alarm"));
        grupa_alarm->setGeometry(QRect(400, 100, 111, 81));
        grupa_alarm->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_alarm->setFlat(true);
        sterowanie_alarm_wyl_2 = new QRadioButton(grupa_alarm);
        sterowanie_alarm_wyl_2->setObjectName(QStringLiteral("sterowanie_alarm_wyl_2"));
        sterowanie_alarm_wyl_2->setGeometry(QRect(10, 40, 101, 41));
        sterowanie_alarm_wyl_2->setChecked(true);
        sterowanie_alarm_wl_2 = new QRadioButton(grupa_alarm);
        sterowanie_alarm_wl_2->setObjectName(QStringLiteral("sterowanie_alarm_wl_2"));
        sterowanie_alarm_wl_2->setGeometry(QRect(10, 20, 101, 31));
        grupa_klimatyzacja_2 = new QGroupBox(tab_2);
        grupa_klimatyzacja_2->setObjectName(QStringLiteral("grupa_klimatyzacja_2"));
        grupa_klimatyzacja_2->setGeometry(QRect(260, 10, 121, 91));
        grupa_klimatyzacja_2->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_klimatyzacja_2->setFlat(true);
        sterowanie_klima_wyl_2 = new QRadioButton(grupa_klimatyzacja_2);
        sterowanie_klima_wyl_2->setObjectName(QStringLiteral("sterowanie_klima_wyl_2"));
        sterowanie_klima_wyl_2->setGeometry(QRect(10, 48, 101, 31));
        sterowanie_klima_wyl_2->setChecked(true);
        sterowanie_klima_wl_2 = new QRadioButton(grupa_klimatyzacja_2);
        sterowanie_klima_wl_2->setObjectName(QStringLiteral("sterowanie_klima_wl_2"));
        sterowanie_klima_wl_2->setGeometry(QRect(10, 20, 101, 31));
        grupa_zaluzje = new QGroupBox(tab_2);
        grupa_zaluzje->setObjectName(QStringLiteral("grupa_zaluzje"));
        grupa_zaluzje->setGeometry(QRect(10, 100, 231, 181));
        grupa_zaluzje->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_zaluzje->setFlat(true);
        sterowanie_zaluzie1_2 = new QSlider(grupa_zaluzje);
        sterowanie_zaluzie1_2->setObjectName(QStringLiteral("sterowanie_zaluzie1_2"));
        sterowanie_zaluzie1_2->setGeometry(QRect(22, 20, 20, 131));
        sterowanie_zaluzie1_2->setMinimum(0);
        sterowanie_zaluzie1_2->setMaximum(100);
        sterowanie_zaluzie1_2->setValue(0);
        sterowanie_zaluzie1_2->setOrientation(Qt::Vertical);
        sterowanie_zaluzje2_2 = new QSlider(grupa_zaluzje);
        sterowanie_zaluzje2_2->setObjectName(QStringLiteral("sterowanie_zaluzje2_2"));
        sterowanie_zaluzje2_2->setGeometry(QRect(102, 20, 20, 131));
        sterowanie_zaluzje2_2->setMinimum(0);
        sterowanie_zaluzje2_2->setMaximum(100);
        sterowanie_zaluzje2_2->setValue(0);
        sterowanie_zaluzje2_2->setOrientation(Qt::Vertical);
        sterowanie_zaluzje3_2 = new QSlider(grupa_zaluzje);
        sterowanie_zaluzje3_2->setObjectName(QStringLiteral("sterowanie_zaluzje3_2"));
        sterowanie_zaluzje3_2->setGeometry(QRect(182, 20, 20, 131));
        sterowanie_zaluzje3_2->setMinimum(0);
        sterowanie_zaluzje3_2->setMaximum(100);
        sterowanie_zaluzje3_2->setValue(0);
        sterowanie_zaluzje3_2->setOrientation(Qt::Vertical);
        opis1_2 = new QLabel(grupa_zaluzje);
        opis1_2->setObjectName(QStringLiteral("opis1_2"));
        opis1_2->setGeometry(QRect(10, 150, 51, 21));
        opis2_2 = new QLabel(grupa_zaluzje);
        opis2_2->setObjectName(QStringLiteral("opis2_2"));
        opis2_2->setGeometry(QRect(84, 150, 61, 21));
        opis3_2 = new QLabel(grupa_zaluzje);
        opis3_2->setObjectName(QStringLiteral("opis3_2"));
        opis3_2->setGeometry(QRect(162, 150, 61, 21));
        grupa_dzwi = new QGroupBox(tab_2);
        grupa_dzwi->setObjectName(QStringLiteral("grupa_dzwi"));
        grupa_dzwi->setGeometry(QRect(120, 10, 121, 91));
        grupa_dzwi->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_dzwi->setFlat(true);
        sterowanie_dzwi_zamkniete_2 = new QRadioButton(grupa_dzwi);
        sterowanie_dzwi_zamkniete_2->setObjectName(QStringLiteral("sterowanie_dzwi_zamkniete_2"));
        sterowanie_dzwi_zamkniete_2->setGeometry(QRect(10, 51, 91, 31));
        sterowanie_dzwi_zamkniete_2->setChecked(true);
        sterowanie_dzwi_otwarte_2 = new QRadioButton(grupa_dzwi);
        sterowanie_dzwi_otwarte_2->setObjectName(QStringLiteral("sterowanie_dzwi_otwarte_2"));
        sterowanie_dzwi_otwarte_2->setGeometry(QRect(10, 26, 91, 21));
        grupa_swiatlo = new QGroupBox(tab_2);
        grupa_swiatlo->setObjectName(QStringLiteral("grupa_swiatlo"));
        grupa_swiatlo->setGeometry(QRect(10, 10, 111, 91));
        grupa_swiatlo->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_swiatlo->setFlat(true);
        sterowanie_swiatlo1_2 = new QCheckBox(grupa_swiatlo);
        sterowanie_swiatlo1_2->setObjectName(QStringLiteral("sterowanie_swiatlo1_2"));
        sterowanie_swiatlo1_2->setGeometry(QRect(6, 20, 81, 17));
        sterowanie_swiatlo2_2 = new QCheckBox(grupa_swiatlo);
        sterowanie_swiatlo2_2->setObjectName(QStringLiteral("sterowanie_swiatlo2_2"));
        sterowanie_swiatlo2_2->setGeometry(QRect(6, 43, 91, 17));
        sterowanie_swiatlo3_2 = new QCheckBox(grupa_swiatlo);
        sterowanie_swiatlo3_2->setObjectName(QStringLiteral("sterowanie_swiatlo3_2"));
        sterowanie_swiatlo3_2->setGeometry(QRect(6, 65, 91, 17));
        grupa_okna = new QGroupBox(tab_2);
        grupa_okna->setObjectName(QStringLiteral("grupa_okna"));
        grupa_okna->setGeometry(QRect(400, 10, 201, 91));
        grupa_okna->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_okna->setFlat(true);
        sterowanie_okno1_2 = new QCheckBox(grupa_okna);
        sterowanie_okno1_2->setObjectName(QStringLiteral("sterowanie_okno1_2"));
        sterowanie_okno1_2->setGeometry(QRect(10, 20, 141, 21));
        sterowanie_okno2_2 = new QCheckBox(grupa_okna);
        sterowanie_okno2_2->setObjectName(QStringLiteral("sterowanie_okno2_2"));
        sterowanie_okno2_2->setGeometry(QRect(10, 43, 151, 21));
        sterowanie_okno3_2 = new QCheckBox(grupa_okna);
        sterowanie_okno3_2->setObjectName(QStringLiteral("sterowanie_okno3_2"));
        sterowanie_okno3_2->setGeometry(QRect(10, 66, 151, 21));
        pushButton = new QPushButton(tab_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(420, 290, 171, 61));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        grupa_klimatyzacja_3 = new QGroupBox(tab_3);
        grupa_klimatyzacja_3->setObjectName(QStringLiteral("grupa_klimatyzacja_3"));
        grupa_klimatyzacja_3->setGeometry(QRect(300, 101, 111, 181));
        grupa_klimatyzacja_3->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_klimatyzacja_3->setFlat(true);
        info_temperatura = new QLCDNumber(grupa_klimatyzacja_3);
        info_temperatura->setObjectName(QStringLiteral("info_temperatura"));
        info_temperatura->setGeometry(QRect(15, 26, 81, 41));
        info_temperatura->setProperty("intValue", QVariant(17));
        sterowanie_temperatura = new QDial(grupa_klimatyzacja_3);
        sterowanie_temperatura->setObjectName(QStringLiteral("sterowanie_temperatura"));
        sterowanie_temperatura->setGeometry(QRect(20, 70, 81, 91));
        sterowanie_temperatura->setMinimum(17);
        sterowanie_temperatura->setMaximum(27);
        sterowanie_wyslij = new QPushButton(tab_3);
        sterowanie_wyslij->setObjectName(QStringLiteral("sterowanie_wyslij"));
        sterowanie_wyslij->setGeometry(QRect(370, 290, 171, 61));
        grupa_dym_2 = new QGroupBox(tab_3);
        grupa_dym_2->setObjectName(QStringLiteral("grupa_dym_2"));
        grupa_dym_2->setGeometry(QRect(430, 190, 111, 91));
        grupa_dym_2->setStyleSheet(QLatin1String("background-color: rgb(65, 65, 65);\n"
""));
        grupa_dym_2->setFlat(true);
        sterowanie_dym_wyl = new QRadioButton(grupa_dym_2);
        sterowanie_dym_wyl->setObjectName(QStringLiteral("sterowanie_dym_wyl"));
        sterowanie_dym_wyl->setGeometry(QRect(10, 43, 91, 41));
        sterowanie_dym_wyl->setChecked(true);
        sterowanie_dym_wl = new QRadioButton(grupa_dym_2);
        sterowanie_dym_wl->setObjectName(QStringLiteral("sterowanie_dym_wl"));
        sterowanie_dym_wl->setGeometry(QRect(10, 23, 101, 31));
        grupa_sprzety_2 = new QGroupBox(tab_3);
        grupa_sprzety_2->setObjectName(QStringLiteral("grupa_sprzety_2"));
        grupa_sprzety_2->setGeometry(QRect(20, 100, 101, 121));
        grupa_sprzety_2->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_sprzety_2->setFlat(true);
        sterowanie_robot3 = new QCheckBox(grupa_sprzety_2);
        sterowanie_robot3->setObjectName(QStringLiteral("sterowanie_robot3"));
        sterowanie_robot3->setGeometry(QRect(8, 66, 111, 21));
        sterowanie_robot2 = new QCheckBox(grupa_sprzety_2);
        sterowanie_robot2->setObjectName(QStringLiteral("sterowanie_robot2"));
        sterowanie_robot2->setGeometry(QRect(8, 44, 101, 21));
        sterowanie_robot1 = new QCheckBox(grupa_sprzety_2);
        sterowanie_robot1->setObjectName(QStringLiteral("sterowanie_robot1"));
        sterowanie_robot1->setGeometry(QRect(8, 23, 101, 21));
        sterowanie_robot4 = new QCheckBox(grupa_sprzety_2);
        sterowanie_robot4->setObjectName(QStringLiteral("sterowanie_robot4"));
        sterowanie_robot4->setGeometry(QRect(8, 89, 101, 21));
        grupa_klimatyzacja_4 = new QGroupBox(tab_3);
        grupa_klimatyzacja_4->setObjectName(QStringLiteral("grupa_klimatyzacja_4"));
        grupa_klimatyzacja_4->setGeometry(QRect(300, 10, 111, 91));
        grupa_klimatyzacja_4->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_klimatyzacja_4->setFlat(true);
        sterowanie_klima_wyl = new QRadioButton(grupa_klimatyzacja_4);
        sterowanie_klima_wyl->setObjectName(QStringLiteral("sterowanie_klima_wyl"));
        sterowanie_klima_wyl->setGeometry(QRect(10, 43, 101, 41));
        sterowanie_klima_wyl->setChecked(true);
        sterowanie_klima_wl = new QRadioButton(grupa_klimatyzacja_4);
        sterowanie_klima_wl->setObjectName(QStringLiteral("sterowanie_klima_wl"));
        sterowanie_klima_wl->setGeometry(QRect(10, 20, 101, 31));
        grupa_dzwi_2 = new QGroupBox(tab_3);
        grupa_dzwi_2->setObjectName(QStringLiteral("grupa_dzwi_2"));
        grupa_dzwi_2->setGeometry(QRect(430, 10, 111, 91));
        grupa_dzwi_2->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_dzwi_2->setFlat(true);
        grupa_dzwi_2->setCheckable(false);
        grupa_dzwi_2->setChecked(false);
        sterowanie_dzwi_zamkniete = new QRadioButton(grupa_dzwi_2);
        sterowanie_dzwi_zamkniete->setObjectName(QStringLiteral("sterowanie_dzwi_zamkniete"));
        sterowanie_dzwi_zamkniete->setGeometry(QRect(8, 50, 101, 31));
        sterowanie_dzwi_zamkniete->setChecked(true);
        sterowanie_dzwi_otwarte = new QRadioButton(grupa_dzwi_2);
        sterowanie_dzwi_otwarte->setObjectName(QStringLiteral("sterowanie_dzwi_otwarte"));
        sterowanie_dzwi_otwarte->setGeometry(QRect(8, 30, 101, 21));
        grupa_zaluzje_2 = new QGroupBox(tab_3);
        grupa_zaluzje_2->setObjectName(QStringLiteral("grupa_zaluzje_2"));
        grupa_zaluzje_2->setGeometry(QRect(140, 100, 141, 181));
        grupa_zaluzje_2->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_zaluzje_2->setFlat(true);
        sterowanie_zaluzie1 = new QSlider(grupa_zaluzje_2);
        sterowanie_zaluzie1->setObjectName(QStringLiteral("sterowanie_zaluzie1"));
        sterowanie_zaluzie1->setGeometry(QRect(20, 20, 20, 131));
        sterowanie_zaluzie1->setMinimum(0);
        sterowanie_zaluzie1->setMaximum(100);
        sterowanie_zaluzie1->setValue(0);
        sterowanie_zaluzie1->setOrientation(Qt::Vertical);
        sterowanie_zaluzje2 = new QSlider(grupa_zaluzje_2);
        sterowanie_zaluzje2->setObjectName(QStringLiteral("sterowanie_zaluzje2"));
        sterowanie_zaluzje2->setGeometry(QRect(100, 20, 20, 131));
        sterowanie_zaluzje2->setMinimum(0);
        sterowanie_zaluzje2->setMaximum(100);
        sterowanie_zaluzje2->setValue(0);
        sterowanie_zaluzje2->setOrientation(Qt::Vertical);
        opis1 = new QLabel(grupa_zaluzje_2);
        opis1->setObjectName(QStringLiteral("opis1"));
        opis1->setGeometry(QRect(10, 150, 51, 21));
        opis2 = new QLabel(grupa_zaluzje_2);
        opis2->setObjectName(QStringLiteral("opis2"));
        opis2->setGeometry(QRect(80, 150, 61, 21));
        grupa_alarm_2 = new QGroupBox(tab_3);
        grupa_alarm_2->setObjectName(QStringLiteral("grupa_alarm_2"));
        grupa_alarm_2->setGeometry(QRect(430, 100, 111, 91));
        grupa_alarm_2->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_alarm_2->setFlat(true);
        sterowanie_alarm_wyl = new QRadioButton(grupa_alarm_2);
        sterowanie_alarm_wyl->setObjectName(QStringLiteral("sterowanie_alarm_wyl"));
        sterowanie_alarm_wyl->setGeometry(QRect(10, 44, 101, 41));
        sterowanie_alarm_wyl->setChecked(true);
        sterowanie_alarm_wl = new QRadioButton(grupa_alarm_2);
        sterowanie_alarm_wl->setObjectName(QStringLiteral("sterowanie_alarm_wl"));
        sterowanie_alarm_wl->setGeometry(QRect(10, 24, 101, 31));
        grupa_okna_2 = new QGroupBox(tab_3);
        grupa_okna_2->setObjectName(QStringLiteral("grupa_okna_2"));
        grupa_okna_2->setGeometry(QRect(140, 10, 141, 91));
        grupa_okna_2->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_okna_2->setFlat(true);
        sterowanie_okno1 = new QCheckBox(grupa_okna_2);
        sterowanie_okno1->setObjectName(QStringLiteral("sterowanie_okno1"));
        sterowanie_okno1->setGeometry(QRect(5, 29, 131, 21));
        sterowanie_okno2 = new QCheckBox(grupa_okna_2);
        sterowanie_okno2->setObjectName(QStringLiteral("sterowanie_okno2"));
        sterowanie_okno2->setGeometry(QRect(5, 52, 141, 31));
        grupa_swiatlo_2 = new QGroupBox(tab_3);
        grupa_swiatlo_2->setObjectName(QStringLiteral("grupa_swiatlo_2"));
        grupa_swiatlo_2->setGeometry(QRect(20, 10, 101, 91));
        grupa_swiatlo_2->setStyleSheet(QStringLiteral("background-color: rgb(65, 65, 65);"));
        grupa_swiatlo_2->setFlat(true);
        sterowanie_swiatlo1 = new QCheckBox(grupa_swiatlo_2);
        sterowanie_swiatlo1->setObjectName(QStringLiteral("sterowanie_swiatlo1"));
        sterowanie_swiatlo1->setGeometry(QRect(8, 22, 91, 21));
        sterowanie_swiatlo2 = new QCheckBox(grupa_swiatlo_2);
        sterowanie_swiatlo2->setObjectName(QStringLiteral("sterowanie_swiatlo2"));
        sterowanie_swiatlo2->setGeometry(QRect(8, 46, 91, 21));
        sterowanie_swiatlo3 = new QCheckBox(grupa_swiatlo_2);
        sterowanie_swiatlo3->setObjectName(QStringLiteral("sterowanie_swiatlo3"));
        sterowanie_swiatlo3->setGeometry(QRect(8, 70, 91, 21));
        tabWidget->addTab(tab_3, QString());
        MainWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 651, 26));
        MainWindow->setMenuBar(menuBar);

        mainToolBar->addSeparator();

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        sterowanie_polacz->setText(QApplication::translate("MainWindow", "Po\305\202\304\205cz", 0));
        info_nazwa->setText(QApplication::translate("MainWindow", "Brak po\305\202\304\205czenia", 0));
        sterowanie_rozlacz->setText(QApplication::translate("MainWindow", "Roz\305\202\304\205cz", 0));
        info_nazwa_portu->setText(QString());
        opis_nazwa->setText(QApplication::translate("MainWindow", "Nazwa portu:", 0));
        info_nazwa_pomieszczenia_1->setText(QApplication::translate("MainWindow", "Nazwa", 0));
        info_nazwa_pomieszczenia_2->setText(QApplication::translate("MainWindow", "Nazwa", 0));
        opis_nazwa_2->setText(QApplication::translate("MainWindow", "Pomieszczenie 2:", 0));
        opis_nazwa_3->setText(QApplication::translate("MainWindow", "Pomieszczenie 1:", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Konfiguracja", 0));
        grupa_dym->setTitle(QApplication::translate("MainWindow", "Czujnik dymu", 0));
        sterowanie_dym_wyl_2->setText(QApplication::translate("MainWindow", "Wy\305\202\304\205cz", 0));
        sterowanie_dym_wl_2->setText(QApplication::translate("MainWindow", "W\305\202\304\205cz", 0));
        grupa_sprzety->setTitle(QApplication::translate("MainWindow", "Sprz\304\231ty", 0));
        sterowanie_robot3_2->setText(QApplication::translate("MainWindow", "Robot 3", 0));
        sterowanie_robot2_2->setText(QApplication::translate("MainWindow", "Robot 2", 0));
        sterowanie_robot1_2->setText(QApplication::translate("MainWindow", "Robot 1", 0));
        sterowanie_robot6_2->setText(QApplication::translate("MainWindow", "Robot 6", 0));
        sterowanie_robot4_2->setText(QApplication::translate("MainWindow", "Robot 4", 0));
        sterowanie_robot5_2->setText(QApplication::translate("MainWindow", "Robot 5", 0));
        grupa_klimatyzacja->setTitle(QApplication::translate("MainWindow", "Klimatyzacja", 0));
        grupa_alarm->setTitle(QApplication::translate("MainWindow", "Alarm", 0));
        sterowanie_alarm_wyl_2->setText(QApplication::translate("MainWindow", "Wy\305\202\304\205cz", 0));
        sterowanie_alarm_wl_2->setText(QApplication::translate("MainWindow", "W\305\202\304\205cz", 0));
        grupa_klimatyzacja_2->setTitle(QApplication::translate("MainWindow", "Klimatyzacja", 0));
        sterowanie_klima_wyl_2->setText(QApplication::translate("MainWindow", "Wy\305\202\304\205czona", 0));
        sterowanie_klima_wl_2->setText(QApplication::translate("MainWindow", "W\305\202\304\205czona", 0));
        grupa_zaluzje->setTitle(QApplication::translate("MainWindow", "\305\273aluzje", 0));
        opis1_2->setText(QApplication::translate("MainWindow", "Okno 1", 0));
        opis2_2->setText(QApplication::translate("MainWindow", "Okno 2", 0));
        opis3_2->setText(QApplication::translate("MainWindow", "Okno 3", 0));
        grupa_dzwi->setTitle(QApplication::translate("MainWindow", "Drzwi", 0));
        sterowanie_dzwi_zamkniete_2->setText(QApplication::translate("MainWindow", "Zamkni\304\231te", 0));
        sterowanie_dzwi_otwarte_2->setText(QApplication::translate("MainWindow", "Otwarte", 0));
        grupa_swiatlo->setTitle(QApplication::translate("MainWindow", "\305\232wiat\305\202o", 0));
        sterowanie_swiatlo1_2->setText(QApplication::translate("MainWindow", "\305\232wiat\305\202o 1", 0));
        sterowanie_swiatlo2_2->setText(QApplication::translate("MainWindow", "\305\232wiat\305\202o 2", 0));
        sterowanie_swiatlo3_2->setText(QApplication::translate("MainWindow", "\305\232wiatlo 3", 0));
        grupa_okna->setTitle(QApplication::translate("MainWindow", "Okna", 0));
        sterowanie_okno1_2->setText(QApplication::translate("MainWindow", "Okno 1 uchylone", 0));
        sterowanie_okno2_2->setText(QApplication::translate("MainWindow", "Okno 2 uchylone", 0));
        sterowanie_okno3_2->setText(QApplication::translate("MainWindow", "Okno 3 uchylone", 0));
        pushButton->setText(QApplication::translate("MainWindow", "Potwierd\305\272 zmiany", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "Pomieszczenie 1", 0));
        grupa_klimatyzacja_3->setTitle(QApplication::translate("MainWindow", "Klimatyzacja", 0));
        sterowanie_wyslij->setText(QApplication::translate("MainWindow", "Potwierd\305\272 zmiany", 0));
        grupa_dym_2->setTitle(QApplication::translate("MainWindow", "Czujnik dymu", 0));
        sterowanie_dym_wyl->setText(QApplication::translate("MainWindow", "Wy\305\202\304\205cz", 0));
        sterowanie_dym_wl->setText(QApplication::translate("MainWindow", "W\305\202\304\205cz", 0));
        grupa_sprzety_2->setTitle(QApplication::translate("MainWindow", "Sprz\304\231ty", 0));
        sterowanie_robot3->setText(QApplication::translate("MainWindow", "Radio", 0));
        sterowanie_robot2->setText(QApplication::translate("MainWindow", "DVD", 0));
        sterowanie_robot1->setText(QApplication::translate("MainWindow", "Telewizor", 0));
        sterowanie_robot4->setText(QApplication::translate("MainWindow", "Dekoder", 0));
        grupa_klimatyzacja_4->setTitle(QApplication::translate("MainWindow", "Klimatyzacja", 0));
        sterowanie_klima_wyl->setText(QApplication::translate("MainWindow", "Wy\305\202\304\205czona", 0));
        sterowanie_klima_wl->setText(QApplication::translate("MainWindow", "W\305\202\304\205czona", 0));
        grupa_dzwi_2->setTitle(QApplication::translate("MainWindow", "Drzwi", 0));
        sterowanie_dzwi_zamkniete->setText(QApplication::translate("MainWindow", "Zamkni\304\231te", 0));
        sterowanie_dzwi_otwarte->setText(QApplication::translate("MainWindow", "Otwarte", 0));
        grupa_zaluzje_2->setTitle(QApplication::translate("MainWindow", "\305\273aluzje", 0));
        opis1->setText(QApplication::translate("MainWindow", "Okno 1", 0));
        opis2->setText(QApplication::translate("MainWindow", "Okno 2", 0));
        grupa_alarm_2->setTitle(QApplication::translate("MainWindow", "Alarm", 0));
        sterowanie_alarm_wyl->setText(QApplication::translate("MainWindow", "Wy\305\202\304\205cz", 0));
        sterowanie_alarm_wl->setText(QApplication::translate("MainWindow", "W\305\202\304\205cz", 0));
        grupa_okna_2->setTitle(QApplication::translate("MainWindow", "Okna", 0));
        sterowanie_okno1->setText(QApplication::translate("MainWindow", "Okno 1 uchylone", 0));
        sterowanie_okno2->setText(QApplication::translate("MainWindow", "Okno 2 uchylone", 0));
        grupa_swiatlo_2->setTitle(QApplication::translate("MainWindow", "\305\232wiat\305\202o", 0));
        sterowanie_swiatlo1->setText(QApplication::translate("MainWindow", "\305\232wiat\305\202o 1", 0));
        sterowanie_swiatlo2->setText(QApplication::translate("MainWindow", "\305\232wiat\305\202o 2", 0));
        sterowanie_swiatlo3->setText(QApplication::translate("MainWindow", "\305\232wiatlo 3", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "Pomieszczenie 2", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
