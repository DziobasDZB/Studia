#ifndef MYTHREAD_H
#define MYTHREAD_H
#include <QThread>

class Thread: public QThread
{
    Q_OBJECT
public:
    void run();
signals:
    void sygnal();

};







#endif // MYTHREAD_H
