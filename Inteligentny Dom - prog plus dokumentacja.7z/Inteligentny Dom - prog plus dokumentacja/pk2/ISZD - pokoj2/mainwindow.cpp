#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "var.h"
#include <QSerialPortInfo>
#include <QSerialPort>
#include <QDebug>
#include <QSettings>
#include <QString>

QString info = NULL;
QSerialPort *serial;
QString ramka[30] = {"2","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","17","0","0","0","0","0","0","0","0","0"};
QString dane = NULL;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    watek1 = new Thread();
    connect(watek1,SIGNAL(sygnal()),this,SLOT(tick()));
    watek1->start();
    QWidget::setWindowTitle("Inteligentny System Zarządzania Domem");
}

MainWindow::~MainWindow()
{
    serial->close();
    watek1->terminate();
    delete ui;

}

void MainWindow::tick()
{
    if(p==1)

    {
        string_recived = "";
        string_recived = serial->readAll();
        qDebug()<<string_recived<<endl;
        QStringList dane = string_recived.split("|");
        if(dane[0] == numer_pokoju_1)
        {
            if(dane.size()>1)
            {
                if (dane[1] == "1")
                    ui->sterowanie_swiatlo1->setChecked(true);
                else if(dane[1] == "0")
                    ui->sterowanie_swiatlo1->setChecked(false);

                if (dane[2] == "1")
                    ui->sterowanie_swiatlo2->setChecked(true);
                else if(dane[2] == "0")
                    ui->sterowanie_swiatlo2->setChecked(false);

                if (dane[3] == "1")
                    ui->sterowanie_swiatlo3->setChecked(true);
                else if(dane[3] == "0")
                    ui->sterowanie_swiatlo3->setChecked(false);

                if (dane[4] == "1")
                    ui->sterowanie_okno1->setChecked(true);
                else if(dane[4] == "0")
                    ui->sterowanie_okno1->setChecked(false);

                if (dane[5] == "1")
                    ui->sterowanie_okno2->setChecked(true);
                else if(dane[5] == "0")
                    ui->sterowanie_okno2->setChecked(false);

                if (dane[6] == "1")
                    ui->sterowanie_klima_wl->setChecked(true);
                else if(dane[6] == "0")
                    ui->sterowanie_klima_wyl->setChecked(false);

                if (dane[7] == "1")
                    ui->sterowanie_dzwi_otwarte->setChecked(true);
                else if(dane[7] == "0")
                    ui->sterowanie_dzwi_zamkniete->setChecked(true);

                if (dane[11] == "1")
                    ui->sterowanie_robot1->setChecked(true);
                else if(dane[11] == "0")
                    ui->sterowanie_robot1->setChecked(false);

                if (dane[12] == "1")
                    ui->sterowanie_robot2->setChecked(true);
                else if(dane[12] == "0")
                    ui->sterowanie_robot2->setChecked(false);

                if (dane[13] == "1")
                    ui->sterowanie_robot3->setChecked(true);
                else if(dane[13] == "0")
                    ui->sterowanie_robot3->setChecked(false);

                if (dane[14] == "1")
                    ui->sterowanie_robot4->setChecked(true);
                else if(dane[14] == "0")
                    ui->sterowanie_robot4->setChecked(false);

                if (dane[15] == "1")
                    ui->sterowanie_alarm_wl->setChecked(true);
                else if(dane[15] == "0")
                    ui->sterowanie_alarm_wyl->setChecked(true);

                if (dane[16] == "1")
                    ui->sterowanie_dym_wl->setChecked(true);
                else if(dane[16] == "0")
                    ui->sterowanie_dym_wyl->setChecked(true);

                ui->sterowanie_zaluzie1->setSliderPosition(dane[8].toInt());
                ui->sterowanie_zaluzje2->setSliderPosition(dane[9].toInt());

                ui->sterowanie_temperatura->setValue(dane[10].toInt());
                ui->info_temperatura->display(dane[10].toInt());


                for (int o = 1; o<30 ; o++)
                    ramka[o] = dane[o];
            }
        }
    }
}

void MainWindow::on_sterowanie_polacz_clicked()
{
    serial = new QSerialPort(this);
    QString name = ui->info_nazwa_2->text();
    serial->setPortName(name);
    serial->setBaudRate(9600);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    serial->setDataBits(QSerialPort::Data8);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setParity(QSerialPort::NoParity);
    serial->open(QIODevice::ReadWrite);

    if (serial->isOpen())
    {
        qDebug() << "OPEN port" << endl;
        ui->info_nazwa->setText("Połączono port: " + name + ".");
        p=1;
    }

}

void MainWindow::on_sterowanie_rozlacz_clicked()
{
    if (serial->isOpen())
    {
        serial->close();
        if (serial->isOpen() == false)
        {
            qDebug() << "CLOSE port" << endl;
            ui->info_nazwa->setText("Rozłączono port.");
            p=0;
        }
    }
}

void MainWindow::on_sterowanie_wyslij_clicked()
{
    dane = "";
    for(int i=0;i<30;i++)
    {
        if (i!=29)
        {
            dane.append(ramka[i]);
            dane.append("|");
        }
        else
            dane.append(ramka[i]);
    }
    //qDebug()<<dane<<endl;
    QByteArray datagram = NULL;
    datagram.append(dane);
    serial->write(datagram);
}



void MainWindow::on_sterowanie_temperatura_valueChanged(int value)
{
    ui->info_temperatura->display(value);
    ramka[10] = QString::number(value);
}

void MainWindow::on_sterowanie_swiatlo1_clicked(bool checked)
{
    if(checked)
        ramka[1] = "1";
    else
        ramka[1] = "0";

}

void MainWindow::on_sterowanie_swiatlo2_clicked(bool checked)
{
    if(checked)
        ramka[2] = "1";
    else
        ramka[2] = "0";
}

void MainWindow::on_sterowanie_swiatlo3_clicked(bool checked)
{
    if(checked)
        ramka[3] = "1";
    else
        ramka[3] = "0";
}



void MainWindow::on_sterowanie_okno1_clicked(bool checked)
{
    if(checked)
        ramka[4] = "1";
    else
        ramka[4] = "0";
}

void MainWindow::on_sterowanie_okno2_clicked(bool checked)
{
    if(checked)
        ramka[5] = "1";
    else
        ramka[5] = "0";
}


void MainWindow::on_sterowanie_robot1_clicked(bool checked)
{
    if(checked)
        ramka[11] = "1";
    else
        ramka[11] = "0";
}

void MainWindow::on_sterowanie_robot2_clicked(bool checked)
{
    if(checked)
        ramka[12] = "1";
    else
        ramka[12] = "0";
}

void MainWindow::on_sterowanie_robot3_clicked(bool checked)
{
    if(checked)
        ramka[13] = "1";
    else
        ramka[13] = "0";
}

void MainWindow::on_sterowanie_robot4_clicked(bool checked)
{
    if(checked)
        ramka[14] = "1";
    else
        ramka[14] = "0";
}

void MainWindow::on_sterowanie_klima_wl_clicked(bool checked)
{
    if(checked)
        ramka[6] = "1";
    else
        ramka[6] = "0";
}

void MainWindow::on_sterowanie_klima_wyl_clicked(bool checked)
{
    if(checked)
        ramka[6] = "0";
    else
        ramka[6] = "1";
}

void MainWindow::on_sterowanie_dzwi_otwarte_clicked(bool checked)
{
    if(checked)
        ramka[7] = "1";
    else
        ramka[7] = "0";
}

void MainWindow::on_sterowanie_dzwi_zamkniete_clicked(bool checked)
{
    if(checked)
        ramka[7] = "0";
    else
        ramka[7] = "1";
}

void MainWindow::on_sterowanie_alarm_wl_clicked(bool checked)
{
    if(checked)
        ramka[15] = "1";
    else
        ramka[15] = "0";
}

void MainWindow::on_sterowanie_alarm_wyl_clicked(bool checked)
{
    if(checked)
        ramka[15] = "0";
    else
        ramka[15] = "1";
}

void MainWindow::on_sterowanie_dym_wl_clicked(bool checked)
{
    if(checked)
        ramka[16] = "1";
    else
        ramka[16] = "0";
}

void MainWindow::on_sterowanie_dym_wyl_clicked(bool checked)
{
    if(checked)
        ramka[16] = "0";
    else
        ramka[16] = "1";
}

void MainWindow::on_sterowanie_zaluzie1_sliderMoved(int position)
{
    ramka[8] = QString::number(position);
}

void MainWindow::on_sterowanie_zaluzje2_sliderMoved(int position)
{
    ramka[9] = QString::number(position);
}


