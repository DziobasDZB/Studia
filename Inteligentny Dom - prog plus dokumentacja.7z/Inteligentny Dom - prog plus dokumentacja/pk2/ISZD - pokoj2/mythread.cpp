#include <mythread.h>

void Thread::run()
{
    while (this->isRunning())
    {
        emit sygnal();
        this->msleep(1000);
    }
}
