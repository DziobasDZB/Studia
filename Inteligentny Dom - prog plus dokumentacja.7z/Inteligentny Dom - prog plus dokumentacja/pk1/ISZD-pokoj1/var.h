#ifndef VAR
#define VAR

#include <QString>
extern QString name;
extern QString desc;
extern QString manu;
extern int p;
extern QString string_recived;

#endif // VAR

