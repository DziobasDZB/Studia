#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "mythread.h"
#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:

    void tick();

    void on_sterowanie_polacz_clicked();

    void on_sterowanie_rozlacz_clicked();

    void on_sterowanie_wyslij_clicked();

    void on_sterowanie_temperatura_valueChanged(int value);

    void on_sterowanie_swiatlo1_clicked(bool checked);

    void on_sterowanie_swiatlo2_clicked(bool checked);

    void on_sterowanie_swiatlo3_clicked(bool checked);

    void on_sterowanie_okno1_clicked(bool checked);

    void on_sterowanie_okno2_clicked(bool checked);

    void on_sterowanie_okno3_clicked(bool checked);

    void on_sterowanie_robot1_clicked(bool checked);

    void on_sterowanie_robot2_clicked(bool checked);

    void on_sterowanie_robot3_clicked(bool checked);

    void on_sterowanie_robot4_clicked(bool checked);

    void on_sterowanie_robot5_clicked(bool checked);

    void on_sterowanie_robot6_clicked(bool checked);

    void on_sterowanie_klima_wl_clicked(bool checked);

    void on_sterowanie_klima_wyl_clicked(bool checked);

    void on_sterowanie_dzwi_otwarte_clicked(bool checked);

    void on_sterowanie_dzwi_zamkniete_clicked(bool checked);

    void on_sterowanie_alarm_wl_clicked(bool checked);

    void on_sterowanie_alarm_wyl_clicked(bool checked);

    void on_sterowanie_dym_wl_clicked(bool checked);

    void on_sterowanie_dym_wyl_clicked(bool checked);

    void on_sterowanie_zaluzie1_sliderMoved(int position);

    void on_sterowanie_zaluzje2_sliderMoved(int position);

    void on_sterowanie_zaluzje3_sliderMoved(int position);


public:
    Ui::MainWindow *ui;
    Thread *watek1;
};

#endif // MAINWINDOW_H
