#include "var.h"
#include <Qstring.h>

QString name;
QString manu;
QString desc;
int p=0;
QString string_recived;
